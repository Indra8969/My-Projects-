var btn = documentmquerySelectoAll(".btn")



function equal() {
 document.querySelector("input").value = eval( document.querySelector("input").value)
}

function ac() {
  
}